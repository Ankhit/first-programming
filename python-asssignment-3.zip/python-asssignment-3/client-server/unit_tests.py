''' This module tests services provided by the server'''
import unittest
from request_handler import request_handler

class Tester(unittest.TestCase):
    ''' Tester class for testing 
        services provided by server
    '''
    def test_register_user(self):
        '''
            tries to register a test user with ‘test’
            as username and ‘test’ as password
            checks whether it returns success message or not
        '''
        response = request_handler.register_user('test','test')
        actual_output = {'status': 200, 'message': 'Registered successfully !'}
        self.assertEqual(response,actual_output)
    def test_register_user_already_exist(self):
        '''
            tries to register a test user with same
            username and password and checks whether
            it returns failure message or not

        '''
        response = request_handler.register_user('test','test')
        actual_output = {'status':403,'message':'Username already exists !'}
        self.assertEqual(response,actual_output)
    def test_authenticate_user(self):
        '''
            tries to login with existed username
            and password and checks whether it
            returns success message or not.

        '''
        response = request_handler.authenticate_user('test','test','127.0.0.1:65430')
        actual_output = {'status':200,'message':'Authenticated Successfully !'}
        self.assertEqual(response,actual_output)
    def test_authenticate_user_with_invalid_creds(self):
        '''
            tries to login with invalid credentials
            and checks whether it returns failure message or not

        '''
        response = response = request_handler.authenticate_user('test','wrong_password','127.0.0.1:65430')
        actual_output = {'status':401,'message':'Invalid Credentials !'}
        self.assertEqual(response,actual_output)
    def test_create_folder(self):
        '''
            tries to create a new folder and checks
            whether it returns success message or not

        '''
        data = {'command':'create_folder','name':'test_folder'}
        response = request_handler.create_folder(data,'127.0.0.1:65430')
        actual_output = {'message': 'Directory Created', 'status': 200}
        self.assertEqual(response,actual_output)
    def test_create_folder_already_exists(self):
        '''
            tries to create a new folder with same
            name as above and checks whether it
            returns failure message or not.

        '''
        data = {'command':'create_folder','name':'test_folder'}
        response = request_handler.create_folder(data,'127.0.0.1:65430')
        actual_output = {'status':403,'message':'Directory Already Exists'}
        self.assertEqual(response,actual_output)
    def test_list(self):
        '''
            runs list command and checks whether
            it lists previously created folders or not.

        '''
        response = request_handler.list('127.0.0.1:65430')
        actual_output = {'status':200,'message':'test_folder'}
        self.assertEqual(response,actual_output)
    def test_change_folder(self):
        ''' 
            tries to change current working directory
            to previously created folder and checks
            whether it returns success message or not

        '''
        data = {'command':'change_folder','name':'test_folder'}
        response = request_handler.change_folder(data,'127.0.0.1:65430')
        actual_output = {'status':200,'message':'Folder changed'}
        self.assertEqual(response,actual_output)
    def test_change_folder_not_existed(self):
        '''
            tries to change current working directory
            a folder which doesn’t exist and checks whether
            it returns failure message or not

        '''
        data = {'command':'change_folder','name':'not_existed_folder'}
        response = request_handler.change_folder(data,'127.0.0.1:65430')
        actual_output = {'status':404,'message':'No such Directory'}
        self.assertEqual(response,actual_output)
    def test_change_folder_unauthorized(self):
        '''
            tries to traverse out of users home
            folder and checks whether it returns
            failure message or not

        '''
        data = {'command':'change_folder','name':'../../../'}
        response = request_handler.change_folder(data,'127.0.0.1:65430')
        actual_output = {'status':401,'message':'Access Denied!'}
        self.assertEqual(response,actual_output)
    def test_write_file(self):
        '''
            tries to write content to a file and
            checks whether it returns success message or not

        '''
        data = {'command':'write_file','name':'test_file.txt','input':'this is test file'}
        response = request_handler.write_file(data,'127.0.0.1:65430')
        actual_output = {'status':200,'message':"Written to file"}
        self.assertEqual(response,actual_output)
    def test_read_file(self):
        '''
            tries to read from a file created in
            previous test and checks whether it
            returns success message or not.

        '''
        data = {'command':'read_file','name':'test_file.txt'}
        response = request_handler.read_file(data,'127.0.0.1:65430')
        actual_output = {'status':200,'message':"this is test file\n"}
        self.assertEqual(response,actual_output)
    def test_read_file_not_existed(self):
        '''    tries to read a file which
            doesn’t exist and checks whether it
            returns failure message or not.
        '''
        data = {'command':'read_file','name':'not_existed.txt'}
        response = request_handler.read_file(data,'127.0.0.1:65430')
        actual_output = {'status':404,'message':'File not found'}
        self.assertEqual(response,actual_output)

def suite():
    suite = unittest.TestSuite()
    suite.addTest(Tester('test_register_user'))
    suite.addTest(Tester('test_register_user_already_exist'))
    suite.addTest(Tester('test_authenticate_user'))
    suite.addTest(Tester('test_authenticate_user_with_invalid_creds'))
    suite.addTest(Tester('test_create_folder'))
    suite.addTest(Tester('test_create_folder_already_exists'))
    suite.addTest(Tester('test_change_folder'))
    suite.addTest(Tester('test_change_folder_not_existed'))
    suite.addTest(Tester('test_change_folder_unauthorized'))
    suite.addTest(Tester('test_write_file'))
    suite.addTest(Tester('test_read_file'))
    suite.addTest(Tester('test_read_file_not_existed'))
    return suite


if __name__ == '__main__':

    runner = unittest.TextTestRunner(failfast=True)
    runner.run(suite())
