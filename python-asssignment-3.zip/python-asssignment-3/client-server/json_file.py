''' This module reads and writes contents of a json file'''
import json
class JSONFile:
    '''
        JSONFile class for reading and writing
        to json files
        methods:
            read
            write

    '''
    def __init__(self,file):
        self.file = file

    def read(self):
        ''' This methods reads json file
            and returns that json file as a Dictionary object
        '''
        try:
            with open(self.file,'r',encoding='utf-8') as file:
                content = file.read()
                content = json.loads(content)
                return content
        except IOError:
            return {}
        except json.JSONDecodeError:
            return {}

    def write(self,content):
        '''This methods takes a Dictionary object
            writes it to the json file
        '''
        try:
            with open(self.file,'w',encoding='utf-8') as file:
                file.write(json.dumps(content))
        except IOError:
            print('Unable to open the file '+self.file)
        except json.JSONDecodeError:
            print("Can't write to the file !Inavalid JSON format")



users_file = JSONFile('users.json')
