''' This module handles all the service request '''
import os
from pathlib import Path
from json_file import users_file
session ={}

class RequestHandler:
    '''
        RequestHandler class to handle the requests made by the client
        methods:
            register_user
            authenticate_user
            change_folder
            list
            read_file
            write_file
            create_folder
            handle_request
    '''

    def __init__(self):
        if not os.path.isdir('users'):
            os.mkdir('users')
        self.root_folder = os.path.join(os.getcwd(),'users')

    def register_user(self,username,password):
        '''
            This methods registers a new user
            and creates a new folder for the user
            in the users folder
        '''
        try:
            users = users_file.read()
            if username in users:
                return {'status':403,'message':'Username already exists !'}
            users[username]=password
            new_dir_path = os.path.join(self.root_folder,username)
            os.mkdir(new_dir_path)
            users_file.write(users)
            return {'status':200,'message':'Registered successfully !'}

        except Exception as error:
            print('Failed to register user :'+str(error))
            return {'status':500,'message':'Internal server error'}

    def authenticate_user(self,username,password,client):
        '''
            This method authenticates the user
            by checking given username and password
            and adds user to the session dictionary
        '''
        try:
            users = users_file.read()
            if username in users:
                if users[username]==password:
                    user_dir = os.path.join(self.root_folder,username)
                    session[client] = {'username':username,'cwd':user_dir}
                    return {'status':200,'message':'Authenticated Successfully !'}
                return {'status':401,'message':'Invalid Credentials !'}
            return {'status':401,'message':"Username doesn't exist !"}
        except IOError :
            print("Unable to open file")
            return {'status':500,'message':'Internal server error !'}

    def change_folder(self,data,client):
        '''
            This methods changes the current working directory
            to another folder given by the user without
            letting user to traverse out of his user folder
        '''

        change_folder_path = os.path.join(session[client]['cwd'],data['name'])
        if not os.path.isdir(change_folder_path):
            return {'status':404,'message':'No such Directory'}
        os.chdir(change_folder_path)
        change_folder_path = os.getcwd()
        if Path(self.root_folder) in Path(change_folder_path).parents:
            session[client]['cwd']=change_folder_path
            return {'status':200,'message':'Folder changed'}
        return {'status':401,'message':'Access Denied!'}


    def list(self,client):
        '''
            This methods returns a list of all
            files and folders int the users current
            working directory
        '''
        cwd = session[client]['cwd']
        files = os.listdir(cwd)
        output = '\n'.join(files)
        return {'status':200,'message':output}

    def read_file(self,data,client):
        '''
            This methods reads the file
            asked by the user and returns
            the contents of the file if the
            file exists
        '''
        cwd = session[client]['cwd']
        file_path = os.path.join(cwd,data['name'])
        if not os.path.isfile(file_path):
            return {'status':404,'message':'File not found'}
        with open(file_path,'r',encoding='utf-8') as file:
            return {'status':200,'message':file.read()}

    def write_file(self,data,client):
        '''
            This method appends input given
            by the user to the asked file
            and clears the contents of the file
            if no input is given
            if given file doesn't exist it creates
            a new file and writes to it
        '''
        cwd = session[client]['cwd']
        new_file_path = os.path.join(cwd,data['name'])
        if os.path.isdir(new_file_path):
            return {'status':403,'message':"A folder with that name already exists"}
        if not data['input']:
            with open(new_file_path,'w',encoding='utf-8') as file:
                file.write('')
        else:
            with open(new_file_path,'a',encoding='utf-8') as file:
                file.write(data['input']+'\n')
        return {'status':200,'message':"Written to file"}

    def create_folder(self,data,client):
        '''
            This methods creates new folder
            if the folder with the given doesn't
            exist
        '''
        cwd = session[client]['cwd']
        new_dir_path = os.path.join(cwd,data['name'])
        if not os.path.isdir(new_dir_path):
            os.mkdir(new_dir_path)
            return {'status':200,'message':'Directory Created'}
        return {'status':403,'message':'Directory Already Exists'}

    def handle_request(self,data,client):
        '''
            This methods handles all requests
            that came to the server
        '''
        if(client not in session and data['command'] not in ['login','register']):
            return {'status':401,'message':"Not Authenticated ! Please Login"}
        if data['command']=="register":
            return self.register_user(data['username'],data['password'])
        elif data['command']=="login":
            return self.authenticate_user(data['username'],data['password'],client)
        elif data['command']=='change_folder':
            return self.change_folder(data,client)
        elif data['command']=='list':
            return self.list(client)
        elif data['command']=='read_file':
            return self.read_file(data,client)
        elif data['command']=='write_file':
            return self.write_file(data,client)
        elif data['command']=='create_folder':
            return self.create_folder(data,client)
        else:
            return {'status':500,'message':'Invalid command'}

request_handler = RequestHandler()
