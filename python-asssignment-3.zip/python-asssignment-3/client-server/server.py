''' This module handles the connections made by each client'''
import asyncio
import json
from request_handler import request_handler


def get_client_id(client):
    '''
        This function takes a client tuple('127:0.0.1',54645)
        joins the items in that tuple and returns client_id('127:0.0.1:54645')

    '''
    return ':'.join([str(i) for i in client])

async def send_response(writer,data):
    '''
        This function sends resonse sent
        by the server to the user
    '''
    data = json.dumps(data)
    writer.write(data.encode())
    await writer.drain()

async def files_server(reader, writer):
    '''
        This function gets called for every
        connection made to the server by clients

    '''
    client = writer.get_extra_info('peername')
    client = get_client_id(client)
    print('Connection from '+client)
    while True:
        data = await reader.read(100)
        if not data:
            break
        data = json.loads(data)
        response = request_handler.handle_request(data,client)
        await send_response(writer,response)
    writer.close()

async def main(host, port):
    '''
        This function starts the server
        at given host and port
    '''
    print(f'Server started at {host} on port {port}')
    server = await asyncio.start_server(files_server, host, port)
    await server.serve_forever()



try:
    asyncio.run(main('127.0.0.1', 8091))
except KeyboardInterrupt:
    print('\nServer terminated!!!')
except Exception as e:
    print("Something went wrong"+str(e))
