''' This module is client application which interacts with
the users,sends reqests to the server and displays response'''
import asyncio
import json


async def send_request(reader,writer,body):
    '''This functions sends requests to the server'''
    body = json.dumps(body)
    writer.write(body.encode())
    await writer.drain()
    data = await reader.read(100)
    return json.loads(data)

def print_commands():
    ''' This function displays service commands format'''
    print(" change_folder <name>")
    print(" list")
    print(" read_file <name>")
    print(" write_file <name> <content>")
    print(" create_folder <name>")

async def handle_login(reader,writer):
    ''' This function handles registration and login flow '''
    while True:
        print("\nPlease login to use File manager.")
        print("Select an option:")
        print("1.Register")
        print("2.Login")
        option = input("\n$ ")
        if option=="1":
            username=input("Enter a new username:").strip()
            password=input("Enter a password:").strip()
            message = {"command":"register","username":username,"password":password}
            response = await send_request(reader,writer,message)
            if response['status'] == 200:
                print("Registered successfully!!")
            else:
                print(response['message']+"\n")
        elif option=="2":
            print("Login page:")
            username = input("Enter your username :").strip()
            password = input("Enter your password :").strip()
            message = {"command":"login","username":username,"password":password}
            response = await send_request(reader,writer,message)
            if response['status'] == 200:
                print("Logged in successfully!!\n")
                print("Available commands:\n$ commands\n$ quit")
                break
            print(response['message']+"\n")
        elif option == 'quit':
            quit()    

async def handle_commands(reader,writer):
    ''' This function handles the services commands
    and sends appropriate requess  to the server'''
    while True:
        message = input("\n$ ")
        if message.lower() == "quit":
            print("Bye!!")
            break
        tokens = message.split()
        if not tokens:
            continue
        command = tokens[0]
        try:
            if command=="commands":
                print_commands()
            elif command == 'change_folder':
                message = {'command':'change_folder','name':tokens[1]}
                response = await send_request(reader,writer,message)
                print(response['message'])
            elif command == 'list':
                message = {'command':'list'}
                response = await send_request(reader,writer,message)
                print(response['message'])
            elif command == 'read_file':
                message = {'command':'read_file','name':tokens[1]}
                response = await send_request(reader,writer,message)
                print(response['message'])
            elif command == 'write_file':
                if len(tokens)==2:
                    tokens.append('')
                else:
                    tokens[2] = ' '.join(tokens[2:])
                message = {'command':'write_file','name':tokens[1],'input':tokens[2]}
                response = await send_request(reader,writer,message)
                print(response['message'])
            elif command == 'create_folder':
                message = {'command':'create_folder','name':tokens[1]}
                response = await send_request(reader,writer,message)
                print(response['message'])
            else:
                print("Invalid Command!") 

        except IndexError:
            print('Invalid Command format!')


async def main():
    ''' This is main function which makes
    connection to the server and starts the
    client application flow
    '''
    reader, writer = await asyncio.open_connection('127.0.0.1', 8091)
    print("Client Application")
    await handle_login(reader,writer)
    await handle_commands(reader,writer)
    print('Connection closed')
    writer.close()
    await writer.wait_closed()

try:
    asyncio.run(main())
except KeyboardInterrupt :
    print("\nBye!!!")
except ConnectionRefusedError:
    print("Unable to connect to the server!!")
